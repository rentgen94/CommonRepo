#include "libst.h"
#include <math.h>

void * tech_abs_1::getRefByName(std::string name) {
		if (!name.compare("X"))
			return &X;
		if (!name.compare("Y"))
			return &Y;
		else
			return NULL;
	}

void tech_abs_1::on_step(float deltat) {
	Y = abs(X);
};