import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.nio.file.Files;

/**
 * Created by shurbin on 21.09.2016.
 */
public class Main {
    public static void main(String[] args) {
        File folder = new File("D:\\My_Projects\\Worcspace\\ReplaceStringInFiles");
        File[] folderEntries = folder.listFiles();
        for (File entry: folderEntries) {
            if (entry.isFile()){
                if (entry.getName().equals("tech_2v3_1.cpp")) {//.endsWith("cpp")){
                    byte[] bytes = new byte[0];
                    try {
                        bytes = Files.readAllBytes(entry.toPath());
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                    String content = null;
                    try {
                        content = new String(bytes, "UTF-8");
                    } catch (UnsupportedEncodingException e) {
                        e.printStackTrace();
                    }
                    String AfterReplace = content.replace("getRefByName", "GetRefByName");
                    try (FileWriter writer = new FileWriter(entry, false)) {
                        writer.write(AfterReplace);
                        writer.flush();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            }
        }
    }
}
