#include "libst.h"
#include <math.h>

void * tech_3v4_1::getRefByName(std::string name) {
		if (!name.compare("E1"))
			return &E1;
		if (!name.compare("E2"))
			return &E2;
		if (!name.compare("E3"))
			return &E3;
		if (!name.compare("E4"))
			return &E4;
		if (!name.compare("BO1"))
			return &BO1;
		else
			return NULL;
	}

void tech_3v4_1::on_step(float deltat) {
	BO1 = ((E1 && E2 && E3) ||
			(E1 && E2 && E4) ||
			(E1 && E3 && E4) ||
			(E2 && E3 && E4));
};