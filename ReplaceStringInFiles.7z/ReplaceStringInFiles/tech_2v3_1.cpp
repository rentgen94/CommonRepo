#include "libst.h"
#include <math.h>

void * tech_2v3_1::GetRefByName(std::string name) {
		if (!name.compare("E1"))
			return &E1;
		if (!name.compare("E2"))
			return &E2;
		if (!name.compare("E3"))
			return &E3;
		if (!name.compare("BO1"))
			return &BO1;
		else
			return NULL;
	}

void tech_2v3_1::on_step(float deltat) {
	BO1 = (E1 && (E2 || E3) || (E2 && E3));
};